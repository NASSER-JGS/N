/**
 * ناصر AI — Proxy آمن بين واجهة الموقع و Groq API (نسخة Vercel)
 * ==============================================================
 * الهدف: إخفاء مفاتيح Groq الحقيقية عن أي زائر للموقع.
 * الموقع بيبعت الطلب هنا (/api/chat)، والسيرفر هو اللي يضيف المفتاح
 * الحقيقي (المخزّن سرّياً في إعدادات Vercel) ويكمل الطلب لـ Groq.
 *
 * ── الإعداد المطلوب في Vercel (Project → Settings → Environment Variables) ──
 * ضيف مفتاح أو أكثر بأي شكل من دول:
 *   - متغيرات منفصلة: GROQ_API_KEY_1, GROQ_API_KEY_2, ... (لحد 5)
 *   - أو متغير واحد GROQ_API_KEYS بفاصلة: gsk_xxxx,gsk_yyyy
 *
 * ملحوظة: مفيش "سر داخلي" أو باسورد إضافي هنا بناءً على طلبك — أي حد
 * يعرف رابط موقعك يقدر يستخدم هذا المسار. ده تبسيط مقصود، وممكن نضيف
 * حماية بسيطة بعدين (زي تحديد الدومين المسموح) من غير ما تحتاج تعدل
 * حاجة في index.html.
 */

module.exports = async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.status(204).end();
    return;
  }

  if (req.method !== 'POST') {
    res.status(405).json({ error: { message: 'Method not allowed' } });
    return;
  }

  const keys = [];
  if (process.env.GROQ_API_KEYS) {
    keys.push(...process.env.GROQ_API_KEYS.split(',').map((k) => k.trim()).filter(Boolean));
  }
  for (let i = 1; i <= 5; i++) {
    const v = process.env[`GROQ_API_KEY_${i}`];
    if (v && v.trim()) keys.push(v.trim());
  }
  const uniqueKeys = [...new Set(keys)];

  if (!uniqueKeys.length) {
    res.status(500).json({ error: { message: 'لا يوجد مفتاح Groq مُعدّ على السيرفر (أضف GROQ_API_KEY_1 في إعدادات Vercel)' } });
    return;
  }

  let body = req.body;
  if (typeof body === 'string') {
    try {
      body = JSON.parse(body);
    } catch (e) {
      res.status(400).json({ error: { message: 'Invalid JSON body' } });
      return;
    }
  }

  const RATE_LIMIT_RETRY_DELAYS = [300, 600, 1200, 2000];
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  let lastStatus = 500;
  let lastData = { error: { message: 'فشل غير معروف' } };

  // نجرب كل المفاتيح المتاحة، وبينهم انتظار بسيط لو الكل مزحوم
  for (let round = 0; round < 2; round++) {
    for (let i = 0; i < uniqueKeys.length; i++) {
      const key = uniqueKeys[i];
      let response, data;
      try {
        response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${key}`,
          },
          body: JSON.stringify(body),
        });
        data = await response.json();
      } catch (err) {
        lastStatus = 502;
        lastData = { error: { message: 'تعذر الوصول لخدمة Groq: ' + err.message } };
        continue;
      }

      const isRateLimited =
        response.status === 429 ||
        data?.error?.type === 'rate_limit_exceeded' ||
        data?.error?.code === 'rate_limit_exceeded';

      // نجاح، أو فشل دائم (مش زحمة) — نرجّع النتيجة فوراً
      if (!isRateLimited) {
        res.status(response.status).json(data);
        return;
      }

      lastStatus = response.status;
      lastData = data;
      // زحمة على المفتاح ده: جرّب المفتاح اللي بعده فوراً بدون انتظار
    }
    // خلصنا كل المفاتيح ولسه زحمة، استنى شوية قبل جولة تانية
    if (round === 0) await sleep(RATE_LIMIT_RETRY_DELAYS[round]);
  }

  // كل المفاتيح مزحومة بعد المحاولات
  res.status(lastStatus || 429).json(lastData);
};
